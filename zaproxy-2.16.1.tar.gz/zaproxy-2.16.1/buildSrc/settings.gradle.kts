plugins {
    id("org.zaproxy.common.settings")
}
